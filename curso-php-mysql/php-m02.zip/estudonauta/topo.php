<?php 
echo"<p class='pequeno'>";
echo "Entrar";
echo"</p>";