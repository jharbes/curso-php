<!DOCTYPE html>
<html>
<head>
	<title>Curso em Video - PHP</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<div class="logoPhp">
			<div class="imagePhp">
				<img src="img4.png">
			</div>
			<div class="autor">
				By Nilkeson Souza
			</div>
		</div>
		<div class="conteudo">
			<div class="conteudoInt">
				<div class="title_lege">
					Curso de PHP para iniciantes - By Nilkeson Souza
				</div>
				<div class="cont_php">
					<?php
					$nome = " Nilkeson Souza "; 

					echo $nome;

					?>
				</div>
			</div>		
		</div>
		<div class="cont_site">
			<div class="url">
				<a href="http://www.google.com.br">www.google.com</a>
			</div>
		</div>
	</div>
</body>
</html>

